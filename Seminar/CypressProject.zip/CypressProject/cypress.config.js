// const { defineConfig } = require("cypress");
// const axios = require("axios");
// require("dotenv").config();

// module.exports = defineConfig({
//   e2e: {
//     supportFile: false,  // Thêm dòng này để tắt yêu cầu file support

//     // URL mặc định (nếu bạn dùng cy.visit('/') thì sẽ trỏ về đây)
//     baseUrl: "https://practicetestautomation.com/practice-test-login/",

//     // Thiết lập reporter Mochawesome
//     reporter: "mochawesome",
//     reporterOptions: {
//       reportDir: "cypress/reports",        // thư mục lưu report
//       overwrite: false,                    // không ghi đè report cũ
//       html: true,                          // xuất file HTML
//       json: true,                          // xuất file JSON
//       charts: true,                        // bật biểu đồ thống kê
//       reportPageTitle: "Cypress Test Report"
//     },

//     // Cấu hình chung cho test run
//     screenshotOnRunFailure: true,           // tự chụp khi test fail
//     video: true,                            // quay video test
//     defaultCommandTimeout: 8000,            // thời gian chờ mặc định 8s
//     chromeWebSecurity: false,               // tắt security (nếu lỗi CORS)
    
//     // Nơi khai báo sự kiện Node
//     setupNodeEvents(on, config) {
//       on("task", {
//         async solveCaptcha({ sitekey, pageurl }) {
//           const API_KEY = process.env.CAPTCHA_KEY;
//           const createRes = await axios.post(
//             "https://api.2captcha.com/createTask",
//             {
//               clientKey: API_KEY,
//               task: {
//                 type: "TurnstileTaskProxyless",
//                 websiteKey: sitekey,
//                 websiteURL: pageurl
//               }
//             },
//             { headers: { "Content-Type": "application/json" } }
//           );

//           const taskId = createRes.data.taskId;
//           if (!taskId) throw new Error("No taskId returned");

//           return new Promise((resolve, reject) => {
//             const interval = setInterval(async () => {
//               try {
//                 const resultRes = await axios.post(
//                   "https://api.2captcha.com/getTaskResult",
//                   { clientKey: API_KEY, taskId },
//                   { headers: { "Content-Type": "application/json" } }
//                 );

//                 if (resultRes.data.status === "ready") {
//                   clearInterval(interval);
//                   resolve(resultRes.data.solution.token);
//                 } else if (resultRes.data.status === "failed") {
//                   clearInterval(interval);
//                   reject(new Error("Captcha solving failed"));
//                 }
//               } catch (err) {
//                 clearInterval(interval);
//                 reject(err);
//               }
//             }, 5000); // Poll every 5s
//           });
//         },
//       });
//       return config;
//     }
//   }
// });


const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    // URL mặc định (nếu bạn dùng cy.visit('/') thì sẽ trỏ về đây)
    baseUrl: "https://practicetestautomation.com/practice-test-login/",

    // Thiết lập reporter Mochawesome
    reporter: "mochawesome",
    reporterOptions: {
      reportDir: "cypress/reports",        // thư mục lưu report
      overwrite: false,                    // không ghi đè report cũ
      html: true,                          // xuất file HTML
      json: true,                          // xuất file JSON
      charts: true,                        // bật biểu đồ thống kê
      reportPageTitle: "Cypress Test Report"
    },

    // Cấu hình chung cho test run
    screenshotOnRunFailure: true,           // tự chụp khi test fail
    video: true,                            // quay video test
    defaultCommandTimeout: 8000,            // thời gian chờ mặc định 8s
    chromeWebSecurity: false,               // tắt security (nếu lỗi CORS)
    
    // Nơi khai báo sự kiện Node (có thể mở rộng sau)
    setupNodeEvents(on, config) {
      // implement node event listeners here nếu cần thêm logic sau này
      return config;
    }
  }
});
