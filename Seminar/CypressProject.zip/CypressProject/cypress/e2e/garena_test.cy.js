describe('Garena Website - Basic Smoke Tests', () => {

  // Test 1: Kiểm tra truy cập trang chủ
  it('Should open Garena homepage successfully', () => {
    cy.visit('https://www.garena.vn/')
    cy.title().should('include', 'Garena')
  })

  // Test 2: Kiểm tra logo Garena hiển thị
  it('Should display Garena logo', () => {
    cy.visit('https://www.garena.vn/')
    cy.get('img[alt="Garena"]').should('be.visible')
  })

  // Test 3: Kiểm tra menu games hiển thị đúng
  it('Should display Games menu correctly', () => {
    cy.visit('https://www.garena.vn/')
    cy.contains('Sản phẩm').should('be.visible')
  })

  // Test 4: Kiểm tra click mở trang Liên Quân Mobile
  it('Should navigate to Lien Quan Mobile page', () => {
    cy.visit('https://www.garena.vn/')
    cy.contains('Liên Quân Mobile').click({force: true})
    cy.url().should('include', 'lienquan')
  })

  // Test 5: Kiểm tra phần footer hiển thị thông tin công ty
  it('Should show company info in footer', () => {
    cy.visit('https://www.garena.vn/')
    cy.get('footer').should('contain.text', 'Công ty Cổ phần Giải trí và Thể thao Điện tử Việt Nam')
  })

})
