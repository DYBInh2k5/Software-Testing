// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
// Function để solve reCAPTCHA qua 2Captcha API
Cypress.Commands.add('solveRecaptcha', () => {
  // Lấy sitekey từ element reCAPTCHA
  cy.get('div.g-recaptcha').invoke('attr', 'data-sitekey').then((sitekey) => {
    if (!sitekey) {
      cy.log('No reCAPTCHA found');
      return;
    }

    // Gửi request đến 2Captcha để solve
    cy.request({
      method: 'POST',
      url: 'http://2captcha.com/in.php',
      form: true,
      body: {
        key: 'YOUR_2CAPTCHA_API_KEY',  // Thay bằng key thật
        method: 'userrecaptcha',
        googlekey: sitekey,
        pageurl: Cypress.config('baseUrl') + '/sach-trong-nuoc.html',  // URL trang
        json: 1
      }
    }).then((response) => {
      const captchaId = response.body.request;
      cy.wait(20000);  // Chờ 20s để solve (có thể poll)

      // Lấy token từ 2Captcha
      cy.request({
        url: `http://2captcha.com/res.php?key=YOUR_2CAPTCHA_API_KEY&action=get&id=${captchaId}&json=1`
      }).then((res) => {
        const token = res.body.request;
        // Set token vào hidden input hoặc callback
        cy.window().then((win) => {
          win.document.querySelector('#g-recaptcha-response').innerHTML = token;
        });
      });
    });
  });
});