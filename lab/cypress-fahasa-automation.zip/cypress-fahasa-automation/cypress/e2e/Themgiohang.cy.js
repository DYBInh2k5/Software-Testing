/// <reference types="cypress" />

describe('Week 11 Practice - Fahasa', () => {

  before(() => {
    const url = 'https://www.fahasa.com/sach-trong-nuoc.html';
    cy.visit(url, {
      failOnStatusCode: false,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://www.google.com/',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1'
      }
    });

    // Detect Cloudflare challenge iframe
    cy.get('iframe[src*="challenges.cloudflare.com"]', { timeout: 10000 }).should('be.visible').then($iframe => {
      // Extract sitekey from src (e.g., sitekey=0x4AAAAAA...)
      const src = $iframe.attr('src');
      const sitekeyMatch = src.match(/sitekey=([^&]+)/);
      const sitekey = sitekeyMatch ? sitekeyMatch[1] : null;

      if (sitekey) {
        cy.task('solveCaptcha', { sitekey, pageurl: url }).then(token => {
          cy.window().then(win => {
            // Inject token into the hidden input
            const responseInput = win.document.querySelector('[name="cf-turnstile-response"]');
            if (responseInput) {
              responseInput.value = token;

              // Dispatch 'change' event to trigger verification
              const event = new win.Event('change', { bubbles: true });
              responseInput.dispatchEvent(event);

              // Optionally call callback if exists
              if (win.tsCallback) {
                win.tsCallback(token);
              }
            }
            // Wait for processing
            cy.wait(3000);
            // Reload to apply changes and bypass challenge
            cy.reload();
          });
        });
      } else {
        // Auto click the verify checkbox if no sitekey or as fallback
        cy.wrap($iframe).its('0.contentDocument.body').find('div.mark').click(); // Thêm dòng này để tự check verify human
      }
    });

    // Assert page loaded without challenge
    cy.get('body').should('not.contain', 'Verify you are human');
    cy.wait(5000); // Extra wait for full load
  });

  it('Find 3 books and add to cart', () => {
    // Select the first 3 books
    cy.get('.product-item') // Get all products
      .each(($el, index) => {
        if (index < 3) {
          cy.wrap($el).find('.icon-cart').click(); // Click add to cart button
        }
      });
  });

  it('Go to cart and click checkout', () => {
    // Click cart icon
    cy.get('.icon-cart-header').click();
    
    // Click checkout button
    cy.get('a.btn-checkout').click();
    
    // Check URL contains checkout
    cy.url().should('include', '/thanh-toan');
  });
});