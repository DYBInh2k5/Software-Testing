describe('Fahasa - Online Book Purchase Flow', () => {

  const books = [
    "Harry Potter Hòn Đá Phù Thủy",
    "Dế Mèn Phiêu Lưu Ký",
    "Sapiens"
  ];

  it('Search and add 3 books to cart', () => {

    books.forEach((bookName) => {

      cy.visit("https://www.fahasa.com/");
      cy.wait(3000);

      // tìm kiếm
      cy.get("#search").type(bookName + "{enter}");
      cy.wait(3000);

      // click sách đầu tiên (selector thay đổi tùy HTML)
      cy.get(".product-container").first().click();
      cy.wait(2000);

      // verify tiêu đề sách có hiển thị
      cy.get("h1").should("be.visible");

      // thêm vào giỏ
      cy.contains("Thêm vào giỏ hàng").click({ force: true });

      cy.wait(2000);
    });
  });

  it('Verify cart has 3 items', () => {
    cy.visit("https://www.fahasa.com/checkout/cart/");
    cy.wait(3000);

    // kiểm tra có 3 sách trong giỏ
    cy.get(".item-info").should("have.length.at.least", 3);

    // qty = 1
    cy.get(".qty").each(($qty) => {
      cy.wrap($qty).should("have.value", "1");
    });

    // có giá hiển thị
    cy.get(".cart-price").should("exist");
  });

  it('Go to checkout page', () => {
    cy.visit("https://www.fahasa.com/checkout/cart/");
    cy.contains("Tiến hành đặt hàng").click();

    cy.wait(5000);

    // verify các trường thông tin checkout
    cy.contains("Thông tin khách hàng").should("be.visible");

    cy.contains("Hình thức thanh toán").should("be.visible");
  });

});
