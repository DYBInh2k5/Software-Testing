describe('Fahasa Automation: Tìm sách, thêm giỏ hàng, thanh toán', () => {
  it('Tìm 3 sách, thêm vào giỏ và click thanh toán', () => {
    cy.visit('https://www.fahasa.com/sach-trong-nuoc.html', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      },
      failOnStatusCode: false,
    });

    cy.get('body').should('be.visible');
    cy.wait(2000);

    // Tìm và thêm 3 sách (điều chỉnh selector nếu cần)
    cy.get('.product-list .item').should('have.length.at.least', 3);
    cy.get('.product-list .item').each(($el, index) => {
      if (index < 3) {
        cy.wrap($el).find('a.product-name').click();
        cy.get('.btn-buy-now, .add-to-cart').should('be.visible').click();
        cy.go('back');
        cy.wait(1000);
      }
    });

    // Chuyển đến giỏ hàng
    cy.get('.header-cart').click();
    cy.url().should('include', '/gio-hang');

    // Detect và solve hCaptcha nếu xuất hiện
    cy.get('div.h-captcha', { timeout: 10000 }).then(($captcha) => {
      if ($captcha.length) {
        const sitekey = $captcha.attr('data-sitekey');
        const pageurl = cy.url();

        cy.task('solveHCaptcha', { sitekey, pageurl }).then((token) => {
          cy.window().then((win) => {
            win.document.querySelector('.h-captcha-response').innerHTML = token; // Inject token
          });
        });
      }
    });

    // Click thanh toán
    cy.get('.btn-checkout').click();
    cy.url().should('include', '/thanh-toan');
  });
});