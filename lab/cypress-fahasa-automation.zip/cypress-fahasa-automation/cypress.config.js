const { defineConfig } = require('cypress');
const axios = require('axios');
require('dotenv').config();

module.exports = defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      // Task solve hCaptcha
      on('task', {
        async solveHCaptcha({ sitekey, pageurl }) {
          const API_KEY = process.env.TWOCAPTCHA_API_KEY;
          if (!API_KEY) {
            throw new Error('2Captcha API key not set in .env');
          }

          const createResponse = await axios.post(
            'https://api.2captcha.com/createTask',
            {
              clientKey: API_KEY,
              task: {
                type: 'HCaptchaTaskProxyless',
                websiteURL: pageurl,
                websiteKey: sitekey,
              },
            },
            { headers: { 'Content-Type': 'application/json' } }
          );

          const taskId = createResponse.data.taskId;
          if (!taskId) {
            throw new Error('Failed to create task: ' + JSON.stringify(createResponse.data));
          }

          // Poll result
          return new Promise((resolve, reject) => {
            const interval = setInterval(async () => {
              try {
                const resultResponse = await axios.post(
                  'https://api.2captcha.com/getTaskResult',
                  {
                    clientKey: API_KEY,
                    taskId,
                  },
                  { headers: { 'Content-Type': 'application/json' } }
                );

                if (resultResponse.data.status === 'ready') {
                  clearInterval(interval);
                  resolve(resultResponse.data.solution.token);
                }
              } catch (err) {
                clearInterval(interval);
                reject(err);
              }
            }, 5000);
          });
        },
      });

      return config;
    },

    chromeWebSecurity: false,
    userAgent:
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  },

  // Video + Screenshot
  video: true,
  screenshotsFolder: 'cypress/screenshots',
  videosFolder: 'cypress/videos',

  // Báo cáo
  reporter: 'mochawesome',
  reporterOptions: {
    reportDir: 'cypress/report',
    overwrite: false,
    html: false,
    json: true,
  },
});
