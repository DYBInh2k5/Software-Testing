const { test, expect } = require('@playwright/test');
const { chromium } = require('playwright-extra');  // Playwright-extra cho stealth
const StealthPlugin = require('puppeteer-extra-plugin-stealth');  // Stealth plugin
const Captcha = require("2captcha");  // CAPTCHA solver nếu cần

chromium.use(StealthPlugin());  // Áp dụng stealth evasions

// Danh sách User-Agent cập nhật 2025 (từ useragents.me hoặc tương tự)
const userAgents = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0'
];

// Proxies residential (thay bằng proxies thật từ dịch vụ như Bright Data – ví dụ: 'http://user:pass@ip:port')
const proxies = [
  'http://your-username:your-password@proxy-ip1:port',
  'http://your-username:your-password@proxy-ip2:port'
  // Thêm nhiều hơn để rotate
];

// CAPTCHA solver (nếu dùng, thay API key)
const solver = new Captcha.Solver('YOUR_2CAPTCHA_API_KEY');  // Uncomment nếu cần

// Hàm random delay và human actions
function randomDelay(min = 1500, max = 5000) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function mimicHuman(page) {
  await page.waitForTimeout(randomDelay(500, 2000));
  await page.mouse.move(Math.random() * 1920, Math.random() * 1080, { steps: 10 });
  await page.evaluate(() => window.scrollBy(0, Math.random() * 800));
  await page.waitForTimeout(randomDelay(1000, 3000));
}

test('basic test', async () => {
  // Random UA và proxy
  const ua = userAgents[Math.floor(Math.random() * userAgents.length)];
  const proxy = proxies[Math.floor(Math.random() * proxies.length)];

  // Launch với stealth + proxy + headed để debug
  const browser = await chromium.launch({
    headless: false,  // Switch sang true khi ổn định
    proxy: { server: proxy }  // Bỏ nếu chưa có proxy, nhưng recommend dùng
  });

  const context = await browser.newContext({
    userAgent: ua,
    viewport: { width: 1920, height: 1080 },
    ignoreHTTPSErrors: true,
    bypassCSP: true,
    locale: 'en-US',
    timezoneId: 'Asia/Ho_Chi_Minh',  // Thay nếu cần mimic location Việt Nam
    extraHTTPHeaders: {
      'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Sec-Fetch-Site': 'same-origin',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-User': '?1',
      'Sec-Fetch-Dest': 'document'
    }
  });

  // Extra evasions: Ẩn webdriver, spoof languages/plugins
  await context.addInitScript(() => {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en', 'vi'] });
    Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
    Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => Math.floor(Math.random() * 8) + 4 });
  });

  const page = await context.newPage();

  // Kiểm tra CAPTCHA và solve nếu có (uncomment nếu cần)
  // async function solveCaptchaIfPresent(page, url) {
  //   const sitekey = await page.getAttribute('.cf-turnstile', 'data-sitekey') || await page.getAttribute('iframe[src*="captcha"]', 'data-sitekey');
  //   if (sitekey) {
  //     const captchaResponse = await solver.turnstile(sitekey, url);
  //     await page.evaluate((token) => {
  //       document.querySelector('textarea[name="cf-turnstile-response"]')?.value = token;
  //     }, captchaResponse.data);
  //     await page.waitForTimeout(5000);  // Chờ verify
  //   }
  // }

  // Goto evasion test với human mimic
  await page.goto('https://evasions.splashthat.com/');
  await mimicHuman(page);

  // Add script (giữ nguyên nếu cần)
  await page.addInitScript(() => { /* Your stealth script here */ });

  // Goto Fahasa
  await page.goto('https://www.fahasa.com/sach-trong-nuoc/van-hoc-trong-nuoc/tieu-thuyet/vu-than-toan.html', { waitUntil: 'networkidle' });
  await mimicHuman(page);
  // await solveCaptchaIfPresent(page, page.url());  // Uncomment nếu thấy CAPTCHA

  // Add to cart
  await page.locator('.product-item-all').click();
  await mimicHuman(page);

  // Go to cart
  await page.locator('a.btn-checkout').click();
  await mimicHuman(page);

  // Wait for URL
  await page.waitForURL('/than-toan');

  await browser.close();
});